#!/usr/bin/env python3
"""Gera texturas (PNG) e sons (OGG) do mod. Requer: python3, numpy, ffmpeg (libvorbis).
Os arquivos gerados ja vem prontos no projeto; so rode isto se quiser regenerar."""
import os, struct, zlib, wave, subprocess, tempfile
import numpy as np

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "billcipher")

def write_png(path, w, h, px):
    raw = b"".join(b"\x00" + bytes(v for p in row for v in p) for row in px)
    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(png)

def entity_texture(path, body):
    bands = [body, (255, 255, 255, 255), (12, 12, 16, 255), (40, 90, 210, 255)]
    px = [[bands[y // 16] for _ in range(64)] for y in range(64)]
    write_png(path, 64, 64, px)

def item_icon(path):
    T = (0, 0, 0, 0); Y = (255, 215, 40, 255); O = (170, 110, 0, 255)
    K = (12, 12, 16, 255); W = (255, 255, 255, 255); B = (40, 90, 210, 255)
    g = [[T] * 16 for _ in range(16)]
    def put(x, y, c):
        if 0 <= x < 16 and 0 <= y < 16: g[y][x] = c
    for x in range(6, 10):
        put(x, 0, K); put(x, 1, K)
    for x in range(5, 11): put(x, 2, K)
    for y in range(3, 14):
        half = 1 + (y - 3) * 6 // 10
        for x in range(8 - half - 1, 8 + half + 1):
            put(x, y, Y)
        put(8 - half - 1, y, O); put(8 + half, y, O)
    for x in range(1, 15): put(x, 13, O)
    for y in range(8, 11):
        for x in range(6, 10): put(x, y, W)
    put(7, 9, K); put(8, 9, K); put(7, 8, K); put(8, 8, K)
    for x in (4, 5, 6, 9, 10, 11): put(x, 11, B)
    put(5, 12, B); put(10, 12, B)
    put(5, 14, K); put(5, 15, K); put(10, 14, K); put(10, 15, K)
    write_png(path, 16, 16, g)

SR = 44100
def tt(d): return np.linspace(0, d, int(SR * d), endpoint=False)
def adsr(n, a=0.01, r=0.1):
    e = np.ones(n); na = max(1, int(a * SR)); nr = max(1, int(r * SR))
    e[:na] = np.linspace(0, 1, na); e[-nr:] *= np.linspace(1, 0, nr); return e
def sweep(f0, f1, d, shape="sin"):
    t = tt(d); f = f0 * (f1 / f0) ** (t / d); ph = 2 * np.pi * np.cumsum(f) / SR
    return np.sin(ph) if shape == "sin" else 2 * ((ph / (2 * np.pi)) % 1) - 1
def noise(d): return np.random.RandomState(7).uniform(-1, 1, int(SR * d))
def lowpass(x, k):
    k = max(1, int(k)); return np.convolve(x, np.ones(k) / k, mode="same")
def norm(x, peak=0.85):
    m = np.max(np.abs(x)) or 1.0; return x / m * peak

def s_cast():
    d = 0.35; return sweep(900, 300, d) * adsr(int(SR * d), 0.005, 0.2) + 0.2 * noise(d) * adsr(int(SR * d), 0.001, 0.1)
def s_transform():
    d = 1.3; t = tt(d); up = sweep(120, 900, d, "saw") * 0.35
    chord = sum(np.sin(2 * np.pi * f * t) for f in (220, 277, 330, 440)) * 0.18 * np.minimum(1, t / d * 3)
    return (up + chord) * adsr(int(SR * d), 0.05, 0.4)
def s_laugh():
    out = []
    formants = ((700, 300, 1.0), (1200, 400, 0.6), (2600, 500, 0.2))
    def ha(f0a, f0b, d):
        t = tt(d); f = np.linspace(f0a, f0b, len(t)) * (1 + 0.02 * np.sin(2 * np.pi * 6 * t))
        ph = 2 * np.pi * np.cumsum(f) / SR; y = np.zeros(len(t))
        for h in range(1, 40):
            fh = np.mean(f) * h; amp = sum(a * np.exp(-((fh - c) / w) ** 2) for c, w, a in formants)
            y += amp * np.sin(h * ph) / h ** 0.3
        hh = 0.25 * noise(d) * np.exp(-t * 40)
        return (y / 6 + hh) * adsr(len(t), 0.01, d * 0.4)
    for i in range(4):
        out.append(ha(240 - i * 12, 170 - i * 10, 0.2)); out.append(np.zeros(int(SR * 0.09)))
    out.append(ha(260, 120, 0.7))
    return np.concatenate(out)
def s_blast():
    d = 0.7; t = tt(d)
    return (sweep(1400, 90, d, "saw") * 0.5 + lowpass(noise(d), 6) * 0.6) * adsr(len(t), 0.002, 0.45)
def s_teleport():
    d = 0.6; t = tt(d)
    sw = sweep(200, 2400, d) * np.exp(-t * 3)
    sp = sum(np.sin(2 * np.pi * f * t) * np.exp(-((t - c) * 14) ** 2) for f, c in ((2800, 0.35), (3600, 0.42), (4400, 0.5)))
    return (sw + 0.5 * sp) * adsr(len(t), 0.005, 0.2)
def s_eye():
    d = 1.2; t = tt(d); vib = 1 + 0.03 * np.sin(2 * np.pi * 5 * t)
    pad = np.sin(2 * np.pi * 110 * t * vib) + 0.6 * np.sin(2 * np.pi * 165 * t * vib) + 0.4 * np.sin(2 * np.pi * 523 * t)
    return pad * np.sin(np.pi * t / d) ** 1.5 * 0.4
def s_telekinesis():
    d = 0.9; t = tt(d); return (sweep(150, 700, d) + 0.5 * np.sin(2 * np.pi * 60 * t * (1 + 0.5 * t))) * adsr(len(t), 0.05, 0.3) * 0.6
def s_explosion():
    d = 1.4; t = tt(d); boom = sweep(120, 28, d) * np.exp(-t * 3)
    crack = lowpass(noise(d), 12) * np.exp(-t * 5)
    return (boom * 0.9 + crack * 0.8) * adsr(len(t), 0.001, 0.5)
def s_mind():
    d = 1.0; t = tt(d); lfo = np.sin(2 * np.pi * 7 * t)
    return (np.sin(2 * np.pi * (330 + 40 * lfo) * t) + np.sin(2 * np.pi * (333 + 45 * lfo) * t)) * 0.35 * np.sin(np.pi * t / d)
def s_portal():
    d = 1.6; t = tt(d); wob = np.sin(2 * np.pi * 3 * t)
    y = np.sin(2 * np.pi * (90 + 15 * wob) * t) + 0.5 * np.sin(2 * np.pi * (181 + 30 * wob) * t)
    y += 0.25 * lowpass(noise(d), 40) * 8
    return y * np.sin(np.pi * t / d) ** 0.7 * 0.5
def s_chaos():
    d = 2.2; t = tt(d); y = np.zeros(len(t))
    for f in (110, 117, 164, 175, 233, 247):
        y += np.sin(2 * np.pi * f * t * (1 + 0.05 * np.sin(2 * np.pi * 0.7 * t + f)))
    y = np.tanh(y * 0.9) + 0.3 * lowpass(noise(d), 5)
    return y * adsr(len(t), 0.1, 0.8) * 0.6
def s_shield():
    d = 1.0; t = tt(d)
    y = sum(np.sin(2 * np.pi * f * t) * np.exp(-t * k) for f, k in ((880, 3), (1320, 4), (1760, 5), (2640, 7)))
    return y * adsr(len(t), 0.002, 0.3)
def s_supreme():
    d = 2.4; t = tt(d); boom = sweep(90, 30, d) * np.exp(-t * 1.5)
    choir = sum(np.sin(2 * np.pi * f * t * (1 + 0.01 * np.sin(2 * np.pi * 5 * t))) for f in (110, 165, 220, 330, 440)) * 0.18
    return (boom * 1.0 + choir * np.minimum(1, t / 0.6)) * adsr(len(t), 0.005, 1.0)

SOUNDS = dict(cast=s_cast, transform=s_transform, laugh=s_laugh, blast=s_blast, teleport=s_teleport, eye=s_eye,
              telekinesis=s_telekinesis, explosion=s_explosion, mind=s_mind, portal=s_portal, chaos=s_chaos,
              shield=s_shield, supreme=s_supreme)

def write_ogg(name, samples):
    out = os.path.join(ROOT, "sounds", name + ".ogg"); os.makedirs(os.path.dirname(out), exist_ok=True)
    pcm = (np.clip(norm(samples), -1, 1) * 32767).astype("<i2")
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp: wav = tmp.name
    with wave.open(wav, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-c:a", "libvorbis", "-q:a", "4", out], check=True)
    os.remove(wav)

if __name__ == "__main__":
    entity_texture(os.path.join(ROOT, "textures", "entity", "bill.png"), (255, 214, 30, 255))
    entity_texture(os.path.join(ROOT, "textures", "entity", "bill_supreme.png"), (225, 30, 30, 255))
    item_icon(os.path.join(ROOT, "textures", "item", "cipher_wheel.png"))
    for n, fn in SOUNDS.items(): write_ogg(n, fn())
    print("Assets gerados em", os.path.normpath(ROOT))
