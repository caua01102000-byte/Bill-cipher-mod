# Bill Cipher Powers (Forge 1.20.1)

Mod para Minecraft Java 1.20.1 + Forge 47.x com 14 poderes do Bill Cipher.

## Compilar no PC
Requisitos: JDK 17 e Gradle 8.1.1.

    gradle build

O JAR sai em `build/libs/billcipher-1.0.0.jar`.

## Compilar sem PC
Veja o arquivo LEIA-ME.md fora deste projeto (guia do GitHub Actions pelo celular).

## Poderes
Transformação, Manipular Realidade, Rajada de Energia, Teletransporte, Levitação, Olho Demoníaco,
Telecinese, Explosão Caótica, Controle Mental, Transformar Criatura, Portal Dimensional,
Caos Dimensional, Invulnerabilidade e Forma Suprema.

## Comandos
/billcipher give | /billcipher menu | /billcipher cast <poder>

Configuração: config/billcipher-common.toml
