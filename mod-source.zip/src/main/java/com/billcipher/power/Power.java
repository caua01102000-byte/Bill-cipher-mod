package com.billcipher.power;

import net.minecraft.network.chat.Component;

public enum Power {
    TRANSFORM("transform", 20),
    REALITY("reality", 120),
    BLAST("blast", 20),
    TELEPORT("teleport", 40),
    LEVITATE("levitate", 100),
    EYE("eye", 200),
    TELEKINESIS("telekinesis", 100),
    EXPLOSION("explosion", 160),
    MIND("mind", 200),
    POLYMORPH("polymorph", 160),
    PORTAL("portal", 300),
    CHAOS("chaos", 1000),
    SHIELD("shield", 600),
    SUPREME("supreme", 2400);

    public final String id;
    public final int cooldownTicks;

    Power(String id, int cooldownTicks) {
        this.id = id;
        this.cooldownTicks = cooldownTicks;
    }

    public Component displayName() {
        return Component.translatable("power.billcipher." + id);
    }

    public static Power byIndex(int i) {
        Power[] v = values();
        return (i >= 0 && i < v.length) ? v[i] : null;
    }

    public static Power byName(String s) {
        for (Power p : values()) {
            if (p.id.equalsIgnoreCase(s) || p.name().equalsIgnoreCase(s)) {
                return p;
            }
        }
        return null;
    }
}
