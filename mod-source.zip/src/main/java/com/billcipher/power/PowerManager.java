package com.billcipher.power;

import com.billcipher.BillConfig;
import com.billcipher.net.CooldownPacket;
import com.billcipher.net.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Ponto central para lancar poderes: valida forma, recarga e delega para Powers. */
public final class PowerManager {
    private static final Map<UUID, long[]> COOLDOWNS = new HashMap<>();

    private PowerManager() {}

    public static void cast(ServerPlayer p, Power power) {
        ServerLevel level = p.serverLevel();
        int form = FormManager.get(p);

        if (power != Power.TRANSFORM && form == FormManager.NONE) {
            p.displayClientMessage(Component.translatable("msg.billcipher.need_form")
                    .withStyle(ChatFormatting.YELLOW), true);
            return;
        }

        long now = level.getGameTime();
        long[] cds = COOLDOWNS.computeIfAbsent(p.getUUID(), k -> new long[Power.values().length]);
        long ready = cds[power.ordinal()];
        if (now < ready) {
            long secs = (ready - now + 19L) / 20L;
            p.displayClientMessage(Component.translatable("msg.billcipher.cooldown", power.displayName(), secs)
                    .withStyle(ChatFormatting.RED), true);
            return;
        }

        boolean sup = form == FormManager.SUPREME;
        boolean ok;
        switch (power) {
            case TRANSFORM -> ok = Powers.transform(p, level);
            case REALITY -> ok = Powers.reality(p, level, sup);
            case BLAST -> ok = Powers.blast(p, level, sup);
            case TELEPORT -> ok = Powers.teleport(p, level, sup);
            case LEVITATE -> ok = Powers.levitate(p, level, sup);
            case EYE -> ok = Powers.eye(p, level, sup);
            case TELEKINESIS -> ok = Powers.telekinesis(p, level, sup);
            case EXPLOSION -> ok = Powers.explosion(p, level, sup);
            case MIND -> ok = Powers.mind(p, level, sup);
            case POLYMORPH -> ok = Powers.polymorph(p, level, sup);
            case PORTAL -> ok = Powers.portal(p, level, sup);
            case CHAOS -> ok = Powers.chaos(p, level, sup);
            case SHIELD -> ok = Powers.shield(p, level, sup);
            case SUPREME -> ok = Powers.supreme(p, level);
            default -> ok = false;
        }
        if (!ok) {
            return;
        }

        double mult = BillConfig.COOLDOWN_MULTIPLIER.get() * (sup ? 0.5D : 1.0D);
        int cd = (int) Math.round(power.cooldownTicks * mult);
        cds[power.ordinal()] = now + cd;
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new CooldownPacket(power.ordinal(), cd));
    }

    public static void clear(UUID id) {
        COOLDOWNS.remove(id);
    }

    public static void clearAll() {
        COOLDOWNS.clear();
    }
}
