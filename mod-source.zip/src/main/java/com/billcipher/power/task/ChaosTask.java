package com.billcipher.power.task;

import com.billcipher.power.Fx;
import com.billcipher.power.ServerTasks;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.GameRules;
import org.joml.Vector3f;

/**
 * Caos dimensional (lado do servidor): noite + tempestade temporarias, particulas por todo lado,
 * entidades arremessadas aleatoriamente e raios visuais. O tom do ceu/camera e feito no cliente.
 */
public final class ChaosTask implements ServerTasks.Task {
    private static final Vector3f[] COLORS = {Fx.YELLOW, Fx.PURPLE, Fx.RED, Fx.BLUE};

    private final ServerPlayer owner;
    private final ServerLevel level;
    private final int duration;
    private final long origTime;
    private final boolean wasRaining;
    private final boolean wasThundering;
    private final boolean daylightCycle;
    private int age = 0;

    public ChaosTask(ServerPlayer owner, ServerLevel level, int duration) {
        this.owner = owner;
        this.level = level;
        this.duration = duration;
        this.origTime = level.getDayTime();
        this.wasRaining = level.isRaining();
        this.wasThundering = level.isThundering();
        this.daylightCycle = level.getGameRules().getBoolean(GameRules.RULE_DAYLIGHT);

        long midnight = (origTime / 24000L) * 24000L + 18000L;
        level.setDayTime(midnight);
        level.setWeatherParameters(0, duration + 40, true, true);
    }

    private void restore() {
        level.setDayTime(daylightCycle ? origTime + duration : origTime);
        if (wasRaining || wasThundering) {
            level.setWeatherParameters(0, 6000, wasRaining, wasThundering);
        } else {
            level.setWeatherParameters(6000, 0, false, false);
        }
    }

    @Override
    public boolean tick() {
        age++;
        if (owner.isRemoved() || age > duration) {
            restore();
            return true;
        }
        RandomSource r = level.getRandom();
        double ox = owner.getX();
        double oy = owner.getY();
        double oz = owner.getZ();

        if (age % 2 == 0) {
            for (int i = 0; i < 8; i++) {
                double x = ox + (r.nextDouble() - 0.5D) * 32.0D;
                double y = oy + r.nextDouble() * 12.0D - 2.0D;
                double z = oz + (r.nextDouble() - 0.5D) * 32.0D;
                switch (i % 4) {
                    case 0 -> Fx.particles(level, ParticleTypes.PORTAL, x, y, z, 6, 0.5D, 0.5D, 0.5D, 0.6D);
                    case 1 -> Fx.particles(level, ParticleTypes.END_ROD, x, y, z, 2, 0.3D, 0.3D, 0.3D, 0.05D);
                    case 2 -> Fx.particles(level, ParticleTypes.SOUL_FIRE_FLAME, x, y, z, 2, 0.3D, 0.3D, 0.3D, 0.03D);
                    default -> Fx.dust(level, COLORS[r.nextInt(COLORS.length)], 1.6F, x, y, z, 3, 0.4D, 0.4D, 0.4D);
                }
            }
        }

        if (age % 10 == 0) {
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, owner.getBoundingBox().inflate(14.0D),
                    x -> x != owner && x.isAlive())) {
                e.setDeltaMovement((r.nextDouble() - 0.5D) * 0.9D, 0.35D + r.nextDouble() * 0.4D, (r.nextDouble() - 0.5D) * 0.9D);
                e.hurtMarked = true;
                if (r.nextInt(4) == 0) {
                    e.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 40, 0));
                }
            }
        }

        if (age % 30 == 0) {
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
            if (bolt != null) {
                bolt.moveTo(ox + (r.nextDouble() - 0.5D) * 36.0D, oy, oz + (r.nextDouble() - 0.5D) * 36.0D);
                bolt.setVisualOnly(true);
                level.addFreshEntity(bolt);
            }
        }
        return false;
    }
}
