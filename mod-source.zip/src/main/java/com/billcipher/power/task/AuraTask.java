package com.billcipher.power.task;

import com.billcipher.ModSounds;
import com.billcipher.power.Fx;
import com.billcipher.power.ServerTasks;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

/** Aura visual da invulnerabilidade (a protecao em si e aplicada em ServerEvents). */
public final class AuraTask implements ServerTasks.Task {
    private final ServerPlayer owner;
    private final long until;

    public AuraTask(ServerPlayer owner, long until) {
        this.owner = owner;
        this.until = until;
    }

    @Override
    public boolean tick() {
        if (owner.isRemoved() || !owner.isAlive()) {
            return true;
        }
        ServerLevel level = owner.serverLevel();
        long t = level.getGameTime();
        if (t >= until) {
            Fx.sound(owner, ModSounds.CAST.get(), 0.8F, 0.7F);
            Fx.particles(level, ParticleTypes.END_ROD, owner.getX(), owner.getY() + 1.0D, owner.getZ(), 20, 0.6D, 0.9D, 0.6D, 0.1D);
            return true;
        }
        double a = t * 0.35D;
        for (int i = 0; i < 6; i++) {
            double ang = a + i * Math.PI / 3.0D;
            double x = owner.getX() + Math.cos(ang) * 1.1D;
            double z = owner.getZ() + Math.sin(ang) * 1.1D;
            double y = owner.getY() + 1.0D + Math.sin(a * 0.7D + i) * 0.7D;
            Fx.dust(level, Fx.GOLD, 1.0F, x, y, z, 1, 0, 0, 0);
        }
        if (t % 10 == 0) {
            Fx.particles(level, ParticleTypes.END_ROD, owner.getX(), owner.getY() + 1.0D, owner.getZ(), 4, 0.6D, 0.9D, 0.6D, 0.02D);
        }
        return false;
    }
}
