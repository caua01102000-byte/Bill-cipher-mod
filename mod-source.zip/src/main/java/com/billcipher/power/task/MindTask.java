package com.billcipher.power.task;

import com.billcipher.power.Fx;
import com.billcipher.power.ServerTasks;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Mob;

import java.util.List;

/** Faz os monstros afetados atacarem uns aos outros enquanto durar o efeito. */
public final class MindTask implements ServerTasks.Task {
    private final ServerLevel level;
    private final List<Mob> mobs;
    private final int duration;
    private int age = 0;

    public MindTask(ServerLevel level, List<Mob> mobs, int duration) {
        this.level = level;
        this.mobs = mobs;
        this.duration = duration;
    }

    private Mob nearest(Mob self) {
        Mob best = null;
        double bestD = 14.0D * 14.0D;
        for (Mob o : mobs) {
            if (o == self || !o.isAlive()) {
                continue;
            }
            double d = self.distanceToSqr(o);
            if (d < bestD) {
                bestD = d;
                best = o;
            }
        }
        return best;
    }

    @Override
    public boolean tick() {
        age++;
        if (age % 5 == 1) {
            for (Mob m : mobs) {
                if (!m.isAlive()) {
                    continue;
                }
                Mob other = nearest(m);
                m.setTarget(other);
                if (other == null) {
                    m.getNavigation().stop();
                }
            }
        }
        if (age % 4 == 0) {
            for (Mob m : mobs) {
                if (m.isAlive()) {
                    double a = age * 0.4D;
                    Fx.dust(level, Fx.PURPLE, 1.0F,
                            m.getX() + Math.cos(a) * 0.5D, m.getY() + m.getBbHeight() + 0.3D, m.getZ() + Math.sin(a) * 0.5D,
                            2, 0.1D, 0.1D, 0.1D);
                }
            }
        }
        return age >= duration;
    }
}
