package com.billcipher.power.task;

import com.billcipher.ModSounds;
import com.billcipher.power.Fx;
import com.billcipher.power.Keys;
import com.billcipher.power.ServerTasks;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Par de portais ligados: A (perto do jogador) e B (onde ele mirou). Dura alguns segundos. */
public final class PortalTask implements ServerTasks.Task {
    private static final Map<UUID, PortalTask> ACTIVE = new HashMap<>();

    private final UUID ownerId;
    private final ServerLevel level;
    private final Vec3 a;
    private final Vec3 b;
    private final Vec3 axis;
    private final Vec3 normal;
    private final int duration;
    private int age = 0;
    private boolean dead = false;

    private PortalTask(UUID ownerId, ServerLevel level, Vec3 a, Vec3 b, Vec3 axis, Vec3 normal, int duration) {
        this.ownerId = ownerId;
        this.level = level;
        this.a = a;
        this.b = b;
        this.axis = axis;
        this.normal = normal;
        this.duration = duration;
    }

    public static void start(ServerPlayer owner, ServerLevel level, Vec3 a, Vec3 b, Vec3 axis, Vec3 normal, int duration) {
        PortalTask task = new PortalTask(owner.getUUID(), level, a, b, axis, normal, duration);
        PortalTask old = ACTIVE.put(owner.getUUID(), task);
        if (old != null) {
            old.dead = true;
        }
        ServerTasks.add(task);
    }

    public static void clearAll() {
        ACTIVE.clear();
    }

    private void draw(Vec3 c, boolean first) {
        int points = 22;
        for (int i = 0; i < points; i++) {
            double t = (Math.PI * 2.0D * i) / points + age * 0.12D;
            double x = c.x + axis.x * Math.cos(t) * 0.95D;
            double z = c.z + axis.z * Math.cos(t) * 0.95D;
            double y = c.y + 1.4D + Math.sin(t) * 1.45D;
            Fx.dust(level, first ? Fx.YELLOW : Fx.PURPLE, 1.3F, x, y, z, 1, 0, 0, 0);
        }
        Fx.particles(level, ParticleTypes.REVERSE_PORTAL, c.x, c.y + 1.4D, c.z, 4, 0.3D, 0.7D, 0.3D, 0.05D);
    }

    private void warpEntities(Vec3 from, Vec3 to) {
        AABB box = new AABB(from.x - 0.9D, from.y, from.z - 0.9D, from.x + 0.9D, from.y + 2.8D, from.z + 0.9D);
        long now = level.getGameTime();
        for (Entity e : level.getEntitiesOfClass(Entity.class, box,
                x -> x.isAlive() && (x instanceof LivingEntity || x instanceof ItemEntity))) {
            if (e.getPersistentData().getLong(Keys.PORTAL_CD) > now) {
                continue;
            }
            e.getPersistentData().putLong(Keys.PORTAL_CD, now + 60L);
            Vec3 dest = to.add(normal.scale(1.5D));
            AABB moved = e.getBoundingBox().move(dest.x - e.getX(), dest.y - e.getY(), dest.z - e.getZ());
            if (!level.noCollision(e, moved)) {
                dest = to;
            }
            if (e instanceof ServerPlayer sp) {
                sp.connection.teleport(dest.x, dest.y, dest.z, sp.getYRot(), sp.getXRot());
                sp.fallDistance = 0.0F;
            } else {
                e.moveTo(dest.x, dest.y, dest.z, e.getYRot(), e.getXRot());
                if (e instanceof Mob m) {
                    m.getNavigation().stop();
                }
            }
            Fx.sound(level, dest.x, dest.y, dest.z, ModSounds.TELEPORT.get(), 0.8F, 1.2F);
            Fx.particles(level, ParticleTypes.PORTAL, dest.x, dest.y + 1.0D, dest.z, 30, 0.3D, 0.6D, 0.3D, 0.3D);
        }
    }

    @Override
    public boolean tick() {
        if (dead) {
            return true;
        }
        age++;
        if (age > duration) {
            if (ACTIVE.get(ownerId) == this) {
                ACTIVE.remove(ownerId);
            }
            Fx.particles(level, ParticleTypes.POOF, a.x, a.y + 1.4D, a.z, 20, 0.5D, 0.8D, 0.5D, 0.05D);
            Fx.particles(level, ParticleTypes.POOF, b.x, b.y + 1.4D, b.z, 20, 0.5D, 0.8D, 0.5D, 0.05D);
            return true;
        }
        if (age % 2 == 0) {
            draw(a, true);
            draw(b, false);
        }
        if (age % 60 == 1) {
            Fx.sound(level, a.x, a.y, a.z, ModSounds.PORTAL.get(), 0.4F, 1.0F);
            Fx.sound(level, b.x, b.y, b.z, ModSounds.PORTAL.get(), 0.4F, 0.8F);
        }
        warpEntities(a, b);
        warpEntities(b, a);
        return false;
    }
}
