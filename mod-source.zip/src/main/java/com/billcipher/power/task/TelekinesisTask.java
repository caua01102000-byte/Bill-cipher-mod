package com.billcipher.power.task;

import com.billcipher.ModSounds;
import com.billcipher.power.Fx;
import com.billcipher.power.ServerTasks;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.Vec3;

import java.util.Iterator;
import java.util.List;

/** Levanta as entidades alvo na frente do jogador por 1,5 s e depois as arremessa na direcao da mira. */
public final class TelekinesisTask implements ServerTasks.Task {
    private static final int HOLD_TICKS = 30;

    private final ServerPlayer owner;
    private final ServerLevel level;
    private final List<Entity> targets;
    private final boolean sup;
    private int age = 0;
    private boolean thrown = false;

    public TelekinesisTask(ServerPlayer owner, ServerLevel level, List<Entity> targets, boolean sup) {
        this.owner = owner;
        this.level = level;
        this.targets = targets;
        this.sup = sup;
    }

    @Override
    public boolean tick() {
        age++;
        targets.removeIf(e -> !e.isAlive() || e.isRemoved());
        if (targets.isEmpty() || owner.isRemoved() || !owner.isAlive()) {
            return true;
        }

        if (!thrown) {
            Vec3 look = owner.getLookAngle();
            Vec3 center = owner.getEyePosition().add(look.scale(5.0D)).add(0.0D, 0.5D, 0.0D);
            int n = targets.size();
            for (int i = 0; i < n; i++) {
                Entity e = targets.get(i);
                double ang = (Math.PI * 2.0D * i / n) + age * 0.15D;
                double rad = n > 1 ? 1.4D : 0.0D;
                Vec3 hold = center.add(Math.cos(ang) * rad, Math.sin(age * 0.2D + i) * 0.3D, Math.sin(ang) * rad);
                Vec3 cur = e.position().add(0.0D, e.getBbHeight() * 0.5D, 0.0D);
                Vec3 d = hold.subtract(cur).scale(0.35D);
                double len = d.length();
                if (len > 1.3D) {
                    d = d.scale(1.3D / len);
                }
                e.setDeltaMovement(d);
                e.hurtMarked = true;
                e.fallDistance = 0.0F;
                if (e instanceof Mob m) {
                    m.getNavigation().stop();
                }
                if (age % 3 == 0) {
                    Fx.dust(level, Fx.PURPLE, 1.0F, e.getX(), e.getY() + e.getBbHeight() * 0.5D, e.getZ(),
                            4, 0.3D, 0.4D, 0.3D);
                }
            }
            if (age >= HOLD_TICKS) {
                Vec3 dir = owner.getLookAngle();
                for (Entity e : targets) {
                    e.setDeltaMovement(dir.scale(sup ? 3.4D : 2.5D).add(0.0D, 0.1D, 0.0D));
                    e.hurtMarked = true;
                }
                Fx.sound(owner, ModSounds.TELEKINESIS.get(), 1.0F, 1.5F);
                thrown = true;
                age = 0;
            }
            return false;
        }

        Iterator<Entity> it = targets.iterator();
        while (it.hasNext()) {
            Entity e = it.next();
            if (age > 3 && (e.horizontalCollision || e.verticalCollision || e.onGround())) {
                if (e instanceof LivingEntity le) {
                    le.hurt(level.damageSources().indirectMagic(owner, owner), sup ? 16.0F : 8.0F);
                }
                Fx.particles(level, ParticleTypes.EXPLOSION, e.getX(), e.getY() + 0.5D, e.getZ(), 1, 0, 0, 0, 0);
                Fx.dust(level, Fx.YELLOW, 1.5F, e.getX(), e.getY() + 0.5D, e.getZ(), 20, 0.4D, 0.4D, 0.4D);
                Fx.sound(e, ModSounds.CAST.get(), 1.0F, 0.6F);
                it.remove();
            }
        }
        return targets.isEmpty() || age > 40;
    }
}
