package com.billcipher.power.task;

import com.billcipher.power.Fx;
import com.billcipher.power.ServerTasks;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Set;

/** Onda de choque expansiva (Forma Suprema): empurra e fere tudo ao redor. */
public final class ShockwaveTask implements ServerTasks.Task {
    private final ServerPlayer owner;
    private final ServerLevel level;
    private final Vec3 center;
    private final double maxRadius;
    private final float damage;
    private final Set<Integer> hit = new HashSet<>();
    private double radius = 0.0D;

    public ShockwaveTask(ServerPlayer owner, Vec3 center, double maxRadius, float damage) {
        this.owner = owner;
        this.level = owner.serverLevel();
        this.center = center;
        this.maxRadius = maxRadius;
        this.damage = damage;
    }

    @Override
    public boolean tick() {
        radius += 1.4D;
        Vec3 ringCenter = new Vec3(center.x, center.y + 0.2D, center.z);
        Fx.ring(level, Fx.RED, 1.6F, ringCenter, radius, 48);
        Fx.ring(level, Fx.YELLOW, 1.2F, ringCenter.add(0.0D, 0.6D, 0.0D), radius * 0.9D, 32);
        Fx.particles(level, ParticleTypes.SMOKE, center.x, center.y + 0.3D, center.z, 6, radius * 0.4D, 0.1D, radius * 0.4D, 0.02D);

        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class,
                new AABB(center, center).inflate(radius + 2.0D, 4.0D, radius + 2.0D),
                x -> x != owner && x.isAlive())) {
            double dx = e.getX() - center.x;
            double dz = e.getZ() - center.z;
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d <= radius + 1.0D && hit.add(e.getId())) {
                e.hurt(level.damageSources().indirectMagic(owner, owner), damage);
                Vec3 dir = new Vec3(dx, 0.0D, dz).normalize();
                e.setDeltaMovement(dir.x * 1.6D, 0.6D, dir.z * 1.6D);
                e.hurtMarked = true;
            }
        }
        return radius >= maxRadius;
    }
}
