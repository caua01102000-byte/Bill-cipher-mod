package com.billcipher.power;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Raycast a partir da mira do jogador. */
public final class Aim {
    public record Result(Vec3 point, Entity entity, boolean hitBlock, BlockHitResult block) {}

    private Aim() {}

    public static Result trace(ServerPlayer p, double range) {
        Vec3 start = p.getEyePosition();
        Vec3 end = start.add(p.getLookAngle().scale(range));
        BlockHitResult bhr = p.level().clip(new ClipContext(start, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        boolean hitBlock = bhr.getType() != HitResult.Type.MISS;
        if (hitBlock) {
            end = bhr.getLocation();
        }
        EntityHitResult ehr = ProjectileUtil.getEntityHitResult(p, start, end,
                new AABB(start, end).inflate(1.0D),
                e -> !e.isSpectator() && e.isPickable() && e != p,
                start.distanceToSqr(end) + 1.0D);
        if (ehr != null) {
            return new Result(ehr.getLocation(), ehr.getEntity(), false, null);
        }
        return new Result(end, null, hitBlock, hitBlock ? bhr : null);
    }

    /** Procura uma posicao (pes) sem colisao perto de feet, recuando ao longo de dir e subindo ate 3 blocos. */
    public static Vec3 findFree(ServerLevel level, Entity e, Vec3 feet, Vec3 dir) {
        for (int back = 0; back <= 8; back++) {
            Vec3 base = feet.subtract(dir.scale(back * 0.5D));
            for (int up = 0; up <= 3; up++) {
                Vec3 f = base.add(0.0D, up, 0.0D);
                AABB box = e.getBoundingBox().move(f.x - e.getX(), f.y - e.getY(), f.z - e.getZ());
                if (level.noCollision(e, box)) {
                    return f;
                }
            }
        }
        return null;
    }
}
