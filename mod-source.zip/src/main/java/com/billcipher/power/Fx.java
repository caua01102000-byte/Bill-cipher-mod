package com.billcipher.power;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Auxiliares de particulas e sons (todo o efeito visual e enviado pelo servidor). */
public final class Fx {
    public static final Vector3f YELLOW = new Vector3f(1.0F, 0.85F, 0.1F);
    public static final Vector3f GOLD = new Vector3f(1.0F, 0.7F, 0.0F);
    public static final Vector3f BLUE = new Vector3f(0.2F, 0.6F, 1.0F);
    public static final Vector3f PURPLE = new Vector3f(0.65F, 0.2F, 1.0F);
    public static final Vector3f RED = new Vector3f(1.0F, 0.1F, 0.1F);
    public static final Vector3f WHITE = new Vector3f(1.0F, 1.0F, 1.0F);

    private Fx() {}

    public static void dust(ServerLevel l, Vector3f color, float size, double x, double y, double z,
                            int count, double dx, double dy, double dz) {
        l.sendParticles(new DustParticleOptions(color, size), x, y, z, count, dx, dy, dz, 0.0D);
    }

    public static void particles(ServerLevel l, ParticleOptions o, double x, double y, double z,
                                 int count, double dx, double dy, double dz, double speed) {
        l.sendParticles(o, x, y, z, count, dx, dy, dz, speed);
    }

    public static void sound(Level l, double x, double y, double z, SoundEvent s, float vol, float pitch) {
        l.playSound(null, x, y, z, s, SoundSource.PLAYERS, vol, pitch);
    }

    public static void sound(Entity e, SoundEvent s, float vol, float pitch) {
        sound(e.level(), e.getX(), e.getY(), e.getZ(), s, vol, pitch);
    }

    /** Anel horizontal de particulas de poeira. */
    public static void ring(ServerLevel l, Vector3f color, float size, Vec3 c, double radius, int points) {
        for (int i = 0; i < points; i++) {
            double a = (Math.PI * 2.0D * i) / points;
            dust(l, color, size, c.x + Math.cos(a) * radius, c.y, c.z + Math.sin(a) * radius, 1, 0, 0, 0);
        }
    }
}
