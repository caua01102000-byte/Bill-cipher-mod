package com.billcipher.power;

import com.billcipher.BillConfig;
import com.billcipher.ModSounds;
import com.billcipher.net.ChaosPacket;
import com.billcipher.net.ModNetwork;
import com.billcipher.power.task.AuraTask;
import com.billcipher.power.task.ChaosTask;
import com.billcipher.power.task.MindTask;
import com.billcipher.power.task.PortalTask;
import com.billcipher.power.task.ShockwaveTask;
import com.billcipher.power.task.TelekinesisTask;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Implementacao de cada poder. Todos rodam no servidor. */
public final class Powers {
    private Powers() {}

    private static DamageSource magic(ServerLevel level, ServerPlayer p) {
        return level.damageSources().indirectMagic(p, p);
    }

    private static void msg(ServerPlayer p, String key, ChatFormatting color, Object... args) {
        p.displayClientMessage(Component.translatable(key, args).withStyle(color), true);
    }

    // ------------------------------------------------------------------ Transformacao
    static boolean transform(ServerPlayer p, ServerLevel level) {
        boolean becoming = FormManager.get(p) == FormManager.NONE;
        FormManager.set(p, becoming ? FormManager.BILL : FormManager.NONE);
        Fx.sound(p, becoming ? ModSounds.TRANSFORM.get() : ModSounds.CAST.get(), 1.2F, 1.0F);
        if (becoming) {
            Fx.sound(p, ModSounds.LAUGH.get(), 1.0F, 1.0F);
        }
        Fx.dust(level, Fx.YELLOW, 1.6F, p.getX(), p.getY() + 1.0D, p.getZ(), 90, 0.6D, 0.9D, 0.6D);
        Fx.particles(level, ParticleTypes.END_ROD, p.getX(), p.getY() + 1.0D, p.getZ(), 30, 0.5D, 0.9D, 0.5D, 0.15D);
        msg(p, becoming ? "msg.billcipher.transformed" : "msg.billcipher.untransformed", ChatFormatting.GOLD);
        return true;
    }

    // ------------------------------------------------------------------ Manipulacao da realidade
    static boolean reality(ServerPlayer p, ServerLevel level, boolean sup) {
        int r = BillConfig.REALITY_RADIUS.get() + (sup ? 3 : 0);
        BlockPos c = p.blockPosition();
        RandomSource rnd = level.getRandom();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int changed = 0;
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (dx * dx + dy * dy + dz * dz > r * r) {
                        continue;
                    }
                    pos.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                    BlockState st = level.getBlockState(pos);
                    BlockState ns = remap(st, rnd);
                    if (ns != null && level.mayInteract(p, pos)) {
                        level.setBlock(pos, ns, 3);
                        changed++;
                        if (rnd.nextInt(8) == 0) {
                            Fx.dust(level, rnd.nextBoolean() ? Fx.YELLOW : Fx.PURPLE, 1.0F,
                                    pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D, 2, 0.3D, 0.3D, 0.3D);
                        }
                    }
                }
            }
        }
        if (changed == 0) {
            msg(p, "msg.billcipher.reality_none", ChatFormatting.YELLOW);
            return false;
        }
        if (level.isRaining()) {
            level.setWeatherParameters(6000, 0, false, false);
        } else {
            level.setWeatherParameters(0, 2400, true, sup);
        }
        Fx.sound(p, ModSounds.CAST.get(), 1.0F, 0.6F);
        Fx.particles(level, ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1.0D, p.getZ(), 60, r * 0.4D, 0.8D, r * 0.4D, 0.1D);
        msg(p, "msg.billcipher.reality_done", ChatFormatting.GOLD, changed);
        return true;
    }

    private static BlockState remap(BlockState st, RandomSource rnd) {
        if (st.isAir() || st.hasBlockEntity()) {
            return null;
        }
        boolean ground = st.is(BlockTags.DIRT) || st.is(BlockTags.SAND) || st.is(BlockTags.BASE_STONE_OVERWORLD);
        boolean foliage = st.is(BlockTags.LEAVES) || st.is(BlockTags.LOGS);
        if (!ground && !foliage) {
            return null;
        }
        if (rnd.nextInt(100) >= 70) {
            return null;
        }
        int roll = rnd.nextInt(100);
        Block b;
        if (foliage) {
            b = roll < 50 ? Blocks.YELLOW_STAINED_GLASS : Blocks.PURPLE_STAINED_GLASS;
        } else if (roll < 30) {
            b = Blocks.YELLOW_CONCRETE;
        } else if (roll < 50) {
            b = Blocks.BLACK_CONCRETE;
        } else if (roll < 68) {
            b = Blocks.PURPLE_CONCRETE;
        } else if (roll < 82) {
            b = Blocks.BLUE_CONCRETE;
        } else if (roll < 94) {
            b = Blocks.GLOWSTONE;
        } else {
            b = Blocks.GOLD_BLOCK;
        }
        return b.defaultBlockState();
    }

    // ------------------------------------------------------------------ Rajada de energia
    static boolean blast(ServerPlayer p, ServerLevel level, boolean sup) {
        double range = sup ? 56.0D : 40.0D;
        Vec3 start = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 end = start.add(look.scale(range));
        BlockHitResult bhr = level.clip(new ClipContext(start, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (bhr.getType() != HitResult.Type.MISS) {
            end = bhr.getLocation();
        }
        Vec3 dir = end.subtract(start).normalize();
        double len = start.distanceTo(end);
        final Vec3 beamEnd = end;

        for (double d = 1.0D; d < len; d += 0.7D) {
            Vec3 pt = start.add(dir.scale(d)).add(0.0D, -0.2D, 0.0D);
            Fx.dust(level, sup ? Fx.RED : Fx.BLUE, 1.4F, pt.x, pt.y, pt.z, 2, 0.05D, 0.05D, 0.05D);
            Fx.particles(level, ParticleTypes.SOUL_FIRE_FLAME, pt.x, pt.y, pt.z, 1, 0.05D, 0.05D, 0.05D, 0.01D);
        }

        float dmg = sup ? 20.0F : 9.0F;
        List<LivingEntity> hit = level.getEntitiesOfClass(LivingEntity.class,
                new AABB(start, beamEnd).inflate(1.5D), x -> x != p && x.isAlive());
        for (LivingEntity e : hit) {
            if (e.getBoundingBox().inflate(0.6D).clip(start, beamEnd).isPresent()) {
                e.hurt(magic(level, p), dmg);
                e.setSecondsOnFire(sup ? 6 : 3);
                e.push(dir.x * 0.8D, 0.25D, dir.z * 0.8D);
                e.hurtMarked = true;
                Fx.particles(level, ParticleTypes.ELECTRIC_SPARK, e.getX(), e.getY() + e.getBbHeight() * 0.5D, e.getZ(),
                        15, 0.3D, 0.4D, 0.3D, 0.2D);
            }
        }
        Fx.particles(level, ParticleTypes.FLASH, beamEnd.x, beamEnd.y, beamEnd.z, 1, 0, 0, 0, 0);
        Fx.sound(p, ModSounds.BLAST.get(), 1.1F, sup ? 0.8F : 1.0F);
        return true;
    }

    // ------------------------------------------------------------------ Teletransporte
    static boolean teleport(ServerPlayer p, ServerLevel level, boolean sup) {
        double range = sup ? 80.0D : 50.0D;
        Vec3 start = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 end = start.add(look.scale(range));
        BlockHitResult hit = level.clip(new ClipContext(start, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 eyeTarget = hit.getType() == HitResult.Type.MISS ? end : hit.getLocation();
        Vec3 feetGuess = eyeTarget.subtract(0.0D, p.getEyeHeight(), 0.0D);
        Vec3 dest = Aim.findFree(level, p, feetGuess, look);
        if (dest == null) {
            msg(p, "msg.billcipher.no_space", ChatFormatting.YELLOW);
            return false;
        }
        Vec3 from = p.position();
        Fx.sound(level, from.x, from.y, from.z, ModSounds.TELEPORT.get(), 1.0F, 1.0F);
        Fx.particles(level, ParticleTypes.PORTAL, from.x, from.y + 1.0D, from.z, 50, 0.4D, 0.8D, 0.4D, 0.4D);
        Fx.dust(level, Fx.YELLOW, 1.4F, from.x, from.y + 1.0D, from.z, 25, 0.4D, 0.8D, 0.4D);

        p.connection.teleport(dest.x, dest.y, dest.z, p.getYRot(), p.getXRot());
        p.fallDistance = 0.0F;

        Fx.sound(level, dest.x, dest.y, dest.z, ModSounds.TELEPORT.get(), 1.0F, 1.3F);
        Fx.particles(level, ParticleTypes.PORTAL, dest.x, dest.y + 1.0D, dest.z, 50, 0.4D, 0.8D, 0.4D, 0.4D);
        Fx.dust(level, Fx.PURPLE, 1.4F, dest.x, dest.y + 1.0D, dest.z, 25, 0.4D, 0.8D, 0.4D);
        return true;
    }

    // ------------------------------------------------------------------ Levitacao
    static boolean levitate(ServerPlayer p, ServerLevel level, boolean sup) {
        int up = sup ? 80 : 50;
        p.addEffect(new MobEffectInstance(MobEffects.LEVITATION, up, 1, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, up + 400, 0, false, false));
        p.fallDistance = 0.0F;
        Fx.sound(p, ModSounds.TELEKINESIS.get(), 1.0F, 1.4F);
        Fx.ring(level, Fx.PURPLE, 1.4F, new Vec3(p.getX(), p.getY() + 0.1D, p.getZ()), 1.2D, 24);
        Fx.ring(level, Fx.YELLOW, 1.2F, new Vec3(p.getX(), p.getY() + 0.1D, p.getZ()), 0.7D, 16);
        Fx.particles(level, ParticleTypes.END_ROD, p.getX(), p.getY() + 0.5D, p.getZ(), 25, 0.5D, 0.2D, 0.5D, 0.12D);
        msg(p, "msg.billcipher.levitate_done", ChatFormatting.LIGHT_PURPLE);
        return true;
    }

    // ------------------------------------------------------------------ Olho demoniaco
    static boolean eye(ServerPlayer p, ServerLevel level, boolean sup) {
        double r = sup ? 64.0D : 40.0D;
        int dur = sup ? 400 : 240;
        List<LivingEntity> list = level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r),
                x -> x != p && x.isAlive());
        for (LivingEntity e : list) {
            e.addEffect(new MobEffectInstance(MobEffects.GLOWING, dur, 0, false, false));
            Fx.particles(level, ParticleTypes.END_ROD, e.getX(), e.getY() + e.getBbHeight() + 0.3D, e.getZ(),
                    4, 0.2D, 0.1D, 0.2D, 0.02D);
        }
        p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, dur + 100, 0, false, false));
        Fx.sound(p, ModSounds.EYE.get(), 1.0F, 1.0F);
        Fx.dust(level, Fx.YELLOW, 1.2F, p.getX(), p.getEyeY(), p.getZ(), 30, 0.5D, 0.3D, 0.5D);
        msg(p, "msg.billcipher.eye_done", ChatFormatting.GOLD, list.size());
        return true;
    }

    // ------------------------------------------------------------------ Telecinese
    static boolean telekinesis(ServerPlayer p, ServerLevel level, boolean sup) {
        Aim.Result r = Aim.trace(p, 28.0D);
        double radius = sup ? 5.0D : 3.0D;
        Vec3 f = r.point();
        List<Entity> found = level.getEntitiesOfClass(Entity.class, new AABB(f, f).inflate(radius),
                x -> x != p && x.isAlive() && (x instanceof LivingEntity || x instanceof ItemEntity)
                        && !(x instanceof Player pl && pl.isSpectator()));
        if (found.isEmpty()) {
            msg(p, "msg.billcipher.no_target", ChatFormatting.YELLOW);
            return false;
        }
        List<Entity> targets = new ArrayList<>(found.subList(0, Math.min(10, found.size())));
        ServerTasks.add(new TelekinesisTask(p, level, targets, sup));
        Fx.sound(p, ModSounds.TELEKINESIS.get(), 1.0F, 1.0F);
        return true;
    }

    // ------------------------------------------------------------------ Explosao caotica
    private static final MobEffect[] CHAOS_EFFECTS = {
            MobEffects.LEVITATION, MobEffects.POISON, MobEffects.MOVEMENT_SLOWDOWN,
            MobEffects.BLINDNESS, MobEffects.WEAKNESS, MobEffects.CONFUSION
    };

    static boolean explosion(ServerPlayer p, ServerLevel level, boolean sup) {
        Aim.Result r = Aim.trace(p, 30.0D);
        Vec3 c = r.point();
        Vec3 eye = p.getEyePosition();
        if (c.distanceTo(eye) < 4.5D) {
            c = eye.add(p.getLookAngle().scale(4.5D));
        }
        float power = sup ? 6.5F : 4.0F;
        Level.ExplosionInteraction mode = BillConfig.EXPLOSION_BREAKS_BLOCKS.get()
                ? Level.ExplosionInteraction.TNT : Level.ExplosionInteraction.NONE;
        level.explode(p, c.x, c.y, c.z, power, mode);

        double radius = sup ? 10.0D : 7.0D;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(radius),
                x -> x != p && x.isAlive())) {
            MobEffect eff = CHAOS_EFFECTS[level.getRandom().nextInt(CHAOS_EFFECTS.length)];
            e.addEffect(new MobEffectInstance(eff, 100 + level.getRandom().nextInt(100), 0));
        }
        Fx.dust(level, Fx.YELLOW, 2.0F, c.x, c.y + 0.5D, c.z, 80, radius * 0.3D, radius * 0.2D, radius * 0.3D);
        Fx.dust(level, Fx.PURPLE, 2.0F, c.x, c.y + 0.5D, c.z, 80, radius * 0.3D, radius * 0.2D, radius * 0.3D);
        Fx.particles(level, ParticleTypes.FLASH, c.x, c.y + 0.5D, c.z, 1, 0, 0, 0, 0);
        Fx.sound(level, c.x, c.y, c.z, ModSounds.EXPLOSION.get(), 2.0F, 1.0F);
        return true;
    }

    // ------------------------------------------------------------------ Controle mental
    static boolean mind(ServerPlayer p, ServerLevel level, boolean sup) {
        double r = sup ? 26.0D : 15.0D;
        List<Mob> mobs = level.getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(r),
                m -> m.isAlive() && (m instanceof Enemy || m.getTarget() == p));
        if (mobs.isEmpty()) {
            msg(p, "msg.billcipher.no_target", ChatFormatting.YELLOW);
            return false;
        }
        int dur = sup ? 300 : 200;
        for (Mob m : mobs) {
            m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, dur, 1));
            m.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, dur, 1));
            m.addEffect(new MobEffectInstance(MobEffects.CONFUSION, dur, 0));
            m.setTarget(null);
        }
        ServerTasks.add(new MindTask(level, new ArrayList<>(mobs), dur));
        Fx.sound(p, ModSounds.MIND.get(), 1.0F, 1.0F);
        msg(p, "msg.billcipher.mind_done", ChatFormatting.DARK_PURPLE, mobs.size());
        return true;
    }

    // ------------------------------------------------------------------ Transformar criatura
    private static final EntityType<?>[] POLY_TYPES = {
            EntityType.CHICKEN, EntityType.PIG, EntityType.SHEEP, EntityType.COW, EntityType.RABBIT, EntityType.FROG
    };

    static boolean polymorph(ServerPlayer p, ServerLevel level, boolean sup) {
        Aim.Result r = Aim.trace(p, 30.0D);
        Vec3 f = r.point();
        double radius = sup ? 5.0D : 2.5D;
        List<Mob> mobs = new ArrayList<>(level.getEntitiesOfClass(Mob.class, new AABB(f, f).inflate(radius),
                m -> m.isAlive() && !m.hasCustomName() && !(m instanceof EnderDragon) && !(m instanceof WitherBoss)));
        if (r.entity() instanceof Mob am && am.isAlive() && !mobs.contains(am) && !am.hasCustomName()
                && !(am instanceof EnderDragon) && !(am instanceof WitherBoss)) {
            mobs.add(0, am);
        }
        if (mobs.isEmpty()) {
            msg(p, "msg.billcipher.no_target", ChatFormatting.YELLOW);
            return false;
        }
        int max = sup ? 8 : 3;
        int done = 0;
        for (Mob m : mobs) {
            if (done >= max) {
                break;
            }
            EntityType<?> type = POLY_TYPES[level.getRandom().nextInt(POLY_TYPES.length)];
            if (m.getType() == type) {
                continue;
            }
            Entity created = type.create(level);
            if (created == null) {
                continue;
            }
            created.moveTo(m.getX(), m.getY(), m.getZ(), m.getYRot(), m.getXRot());
            if (created instanceof Mob nm) {
                nm.finalizeSpawn(level, level.getCurrentDifficultyAt(m.blockPosition()),
                        MobSpawnType.MOB_SUMMONED, null, null);
            }
            Fx.particles(level, ParticleTypes.POOF, m.getX(), m.getY() + 0.6D, m.getZ(), 25, 0.4D, 0.5D, 0.4D, 0.08D);
            Fx.dust(level, Fx.PURPLE, 1.4F, m.getX(), m.getY() + 0.6D, m.getZ(), 25, 0.4D, 0.5D, 0.4D);
            Fx.dust(level, Fx.YELLOW, 1.4F, m.getX(), m.getY() + 0.6D, m.getZ(), 15, 0.4D, 0.5D, 0.4D);
            m.discard();
            level.addFreshEntity(created);
            done++;
        }
        if (done == 0) {
            msg(p, "msg.billcipher.no_target", ChatFormatting.YELLOW);
            return false;
        }
        Fx.sound(p, ModSounds.MIND.get(), 1.0F, 1.5F);
        Fx.sound(p, ModSounds.LAUGH.get(), 0.8F, 1.2F);
        msg(p, "msg.billcipher.polymorph_done", ChatFormatting.LIGHT_PURPLE, done);
        return true;
    }

    // ------------------------------------------------------------------ Portal dimensional
    static boolean portal(ServerPlayer p, ServerLevel level, boolean sup) {
        Vec3 look = p.getLookAngle();
        Vec3 h = new Vec3(look.x, 0.0D, look.z);
        h = h.lengthSqr() < 1.0E-4D ? new Vec3(0.0D, 0.0D, 1.0D) : h.normalize();
        Vec3 axis = new Vec3(-h.z, 0.0D, h.x);

        Vec3 a = p.position().add(h.scale(2.5D));
        Vec3 aFree = Aim.findFree(level, p, a, h);
        if (aFree != null) {
            a = aFree;
        }

        double range = sup ? 80.0D : 60.0D;
        Vec3 start = p.getEyePosition();
        Vec3 end = start.add(look.scale(range));
        BlockHitResult hit = level.clip(new ClipContext(start, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 feet;
        if (hit.getType() == HitResult.Type.MISS) {
            double y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, Mth.floor(end.x), Mth.floor(end.z));
            feet = new Vec3(end.x, y, end.z);
        } else {
            feet = hit.getLocation().subtract(look.scale(0.8D)).subtract(0.0D, 1.0D, 0.0D);
        }
        Vec3 b = Aim.findFree(level, p, feet, look);
        if (b == null) {
            msg(p, "msg.billcipher.no_space", ChatFormatting.YELLOW);
            return false;
        }
        PortalTask.start(p, level, a, b, axis, h.scale(-1.0D), sup ? 600 : 400);
        Fx.sound(level, a.x, a.y, a.z, ModSounds.PORTAL.get(), 1.2F, 1.0F);
        Fx.sound(level, b.x, b.y, b.z, ModSounds.PORTAL.get(), 1.2F, 0.8F);
        msg(p, "msg.billcipher.portal_done", ChatFormatting.LIGHT_PURPLE);
        return true;
    }

    // ------------------------------------------------------------------ Caos dimensional
    static boolean chaos(ServerPlayer p, ServerLevel level, boolean sup) {
        int dur = sup ? 600 : 400;
        ServerTasks.add(new ChaosTask(p, level, dur));
        ModNetwork.CHANNEL.send(PacketDistributor.DIMENSION.with(level::dimension), new ChaosPacket(dur));
        Fx.sound(p, ModSounds.CHAOS.get(), 1.5F, 1.0F);
        Fx.sound(p, ModSounds.LAUGH.get(), 1.2F, 0.7F);
        msg(p, "msg.billcipher.chaos_done", ChatFormatting.DARK_RED);
        return true;
    }

    // ------------------------------------------------------------------ Invulnerabilidade temporaria
    static boolean shield(ServerPlayer p, ServerLevel level, boolean sup) {
        int dur = sup ? 300 : 200;
        long until = level.getGameTime() + dur;
        Keys.data(p).putLong(Keys.INVULN, until);
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, dur, 4, false, true));
        p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, dur, 0, false, false));
        ServerTasks.add(new AuraTask(p, until));
        Fx.sound(p, ModSounds.SHIELD.get(), 1.2F, 1.0F);
        Fx.dust(level, Fx.GOLD, 1.5F, p.getX(), p.getY() + 1.0D, p.getZ(), 50, 0.6D, 0.9D, 0.6D);
        msg(p, "msg.billcipher.shield_done", ChatFormatting.GOLD, dur / 20);
        return true;
    }

    // ------------------------------------------------------------------ Forma suprema
    static boolean supreme(ServerPlayer p, ServerLevel level) {
        int dur = 600;
        FormManager.set(p, FormManager.SUPREME);
        Keys.data(p).putLong(Keys.SUPREME, level.getGameTime() + dur);
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, dur, 2));
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, dur, 1));
        p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, dur, 1));
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, dur, 1));
        p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, dur, 0));

        ServerTasks.add(new ShockwaveTask(p, p.position(), 18.0D, 12.0F));

        List<LivingEntity> foes = new ArrayList<>(level.getEntitiesOfClass(LivingEntity.class,
                p.getBoundingBox().inflate(22.0D), x -> x != p && x.isAlive() && x instanceof Enemy));
        foes.sort(Comparator.comparingDouble((LivingEntity x) -> x.distanceToSqr(p)));
        for (int i = 0; i < Math.min(5, foes.size()); i++) {
            LivingEntity e = foes.get(i);
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
            if (bolt != null) {
                bolt.moveTo(e.getX(), e.getY(), e.getZ());
                bolt.setVisualOnly(true);
                level.addFreshEntity(bolt);
            }
            e.hurt(magic(level, p), 20.0F);
        }
        Fx.sound(p, ModSounds.SUPREME.get(), 2.0F, 1.0F);
        Fx.sound(p, ModSounds.LAUGH.get(), 1.5F, 0.6F);
        Fx.dust(level, Fx.RED, 2.0F, p.getX(), p.getY() + 1.0D, p.getZ(), 120, 0.8D, 1.2D, 0.8D);
        msg(p, "msg.billcipher.supreme_done", ChatFormatting.DARK_RED, dur / 20);
        return true;
    }
}
