package com.billcipher.power;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;

/** Chaves de NBT do jogador. Os dados ficam na sub-tag "PlayerPersisted" (sobrevive a troca de dimensao). */
public final class Keys {
    public static final String FORM = "billcipher_form";
    public static final String SEL = "billcipher_sel";
    public static final String INVULN = "billcipher_invuln_until";
    public static final String SUPREME = "billcipher_supreme_until";
    public static final String FLIGHT = "billcipher_flight_granted";
    public static final String GIVEN = "billcipher_wheel_given";
    public static final String PORTAL_CD = "billcipher_portal_cd";

    private Keys() {}

    public static CompoundTag data(Player p) {
        CompoundTag root = p.getPersistentData();
        if (!root.contains(Player.PERSISTED_NBT_TAG, 10)) {
            root.put(Player.PERSISTED_NBT_TAG, new CompoundTag());
        }
        return root.getCompound(Player.PERSISTED_NBT_TAG);
    }
}
