package com.billcipher.power;

import com.billcipher.BillCipherMod;
import com.billcipher.power.task.PortalTask;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Agendador simples: executa tarefas uma vez por tick do servidor. */
@Mod.EventBusSubscriber(modid = BillCipherMod.MODID)
public final class ServerTasks {
    /** tick() retorna true quando a tarefa terminou. */
    public interface Task {
        boolean tick();
    }

    private static final List<Task> ACTIVE = new ArrayList<>();
    private static final List<Task> PENDING = new ArrayList<>();

    private ServerTasks() {}

    public static void add(Task t) {
        PENDING.add(t);
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) {
            return;
        }
        if (!PENDING.isEmpty()) {
            ACTIVE.addAll(PENDING);
            PENDING.clear();
        }
        Iterator<Task> it = ACTIVE.iterator();
        while (it.hasNext()) {
            Task t = it.next();
            boolean done;
            try {
                done = t.tick();
            } catch (Exception ex) {
                BillCipherMod.LOGGER.error("Bill Cipher: tarefa falhou e foi cancelada", ex);
                done = true;
            }
            if (done) {
                it.remove();
            }
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        ACTIVE.clear();
        PENDING.clear();
        PortalTask.clearAll();
        PowerManager.clearAll();
    }
}
