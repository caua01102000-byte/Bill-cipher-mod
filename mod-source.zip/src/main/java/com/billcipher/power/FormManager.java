package com.billcipher.power;

import com.billcipher.BillConfig;
import com.billcipher.net.FormSyncPacket;
import com.billcipher.net.ModNetwork;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.network.PacketDistributor;

/** Forma atual do jogador: 0 = normal, 1 = Bill, 2 = Forma Suprema. */
public final class FormManager {
    public static final int NONE = 0;
    public static final int BILL = 1;
    public static final int SUPREME = 2;

    private FormManager() {}

    public static int get(Player p) {
        return Keys.data(p).getInt(Keys.FORM);
    }

    public static void set(ServerPlayer p, int form) {
        CompoundTag data = Keys.data(p);
        data.putInt(Keys.FORM, form);
        if (form == NONE) {
            data.putLong(Keys.SUPREME, 0L);
        }
        applyFlight(p, form);
        sync(p);
    }

    /** Concede voo na forma Bill (e remove ao voltar ao normal, apenas se fomos nos que concedemos). */
    public static void applyFlight(ServerPlayer p, int form) {
        if (p.isCreative() || p.isSpectator()) {
            return;
        }
        Abilities ab = p.getAbilities();
        CompoundTag data = Keys.data(p);
        boolean want = form != NONE && BillConfig.FLIGHT_IN_BILL_FORM.get();
        if (want && !ab.mayfly) {
            ab.mayfly = true;
            data.putBoolean(Keys.FLIGHT, true);
            p.onUpdateAbilities();
        } else if (!want && data.getBoolean(Keys.FLIGHT)) {
            data.putBoolean(Keys.FLIGHT, false);
            ab.mayfly = false;
            ab.flying = false;
            p.onUpdateAbilities();
        }
    }

    /** Envia a forma do jogador para ele mesmo e para quem o esta vendo. */
    public static void sync(ServerPlayer p) {
        ModNetwork.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> p),
                new FormSyncPacket(p.getUUID(), get(p)));
    }
}
