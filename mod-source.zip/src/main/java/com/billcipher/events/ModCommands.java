package com.billcipher.events;

import com.billcipher.BillCipherMod;
import com.billcipher.ModItems;
import com.billcipher.net.ModNetwork;
import com.billcipher.net.OpenMenuPacket;
import com.billcipher.power.Power;
import com.billcipher.power.PowerManager;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.Arrays;

/**
 * Comandos de apoio:
 *   /billcipher give            - entrega a Roda de Cifras
 *   /billcipher menu            - abre o menu de poderes
 *   /billcipher cast [poder]    - lanca um poder pelo nome
 */
@Mod.EventBusSubscriber(modid = BillCipherMod.MODID)
public final class ModCommands {
    private ModCommands() {}

    @SubscribeEvent
    public static void onRegister(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("billcipher")
                .then(Commands.literal("give").executes(ctx -> give(ctx.getSource().getPlayerOrException())))
                .then(Commands.literal("menu").executes(ctx -> menu(ctx.getSource().getPlayerOrException())))
                .then(Commands.literal("cast")
                        .then(Commands.argument("power", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(
                                        Arrays.stream(Power.values()).map(p -> p.id), builder))
                                .executes(ctx -> cast(ctx.getSource(),
                                        StringArgumentType.getString(ctx, "power"))))));
    }

    private static int give(ServerPlayer p) {
        ItemStack wheel = new ItemStack(ModItems.CIPHER_WHEEL.get());
        if (!p.getInventory().add(wheel)) {
            p.drop(wheel, false);
        }
        return 1;
    }

    private static int menu(ServerPlayer p) {
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new OpenMenuPacket());
        return 1;
    }

    private static int cast(CommandSourceStack src, String name) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        Power power = Power.byName(name);
        if (power == null) {
            src.sendFailure(Component.translatable("msg.billcipher.unknown_power", name));
            return 0;
        }
        PowerManager.cast(p, power);
        return 1;
    }
}
