package com.billcipher.events;

import com.billcipher.BillCipherMod;
import com.billcipher.BillConfig;
import com.billcipher.ModItems;
import com.billcipher.net.FormSyncPacket;
import com.billcipher.net.ModNetwork;
import com.billcipher.power.FormManager;
import com.billcipher.power.Fx;
import com.billcipher.power.Keys;
import com.billcipher.power.PowerManager;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

@Mod.EventBusSubscriber(modid = BillCipherMod.MODID)
public final class ServerEvents {
    private ServerEvents() {}

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) {
            return;
        }
        FormManager.set(sp, FormManager.get(sp));

        CompoundTag data = Keys.data(sp);
        if (BillConfig.GIVE_WHEEL_ON_JOIN.get() && !data.getBoolean(Keys.GIVEN)) {
            data.putBoolean(Keys.GIVEN, true);
            ItemStack wheel = new ItemStack(ModItems.CIPHER_WHEEL.get());
            if (!sp.getInventory().add(wheel)) {
                sp.drop(wheel, false);
            }
            sp.sendSystemMessage(Component.translatable("msg.billcipher.welcome").withStyle(ChatFormatting.GOLD));
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        PowerManager.clear(e.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onChangedDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) {
            FormManager.set(sp, FormManager.get(sp));
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) {
            Keys.data(sp).putLong(Keys.INVULN, 0L);
            FormManager.set(sp, FormManager.NONE);
        }
    }

    /** Quando um jogador comeca a ver outro, envia a forma do outro (para renderizar o Bill). */
    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking e) {
        if (e.getTarget() instanceof ServerPlayer target && e.getEntity() instanceof ServerPlayer viewer) {
            ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> viewer),
                    new FormSyncPacket(target.getUUID(), FormManager.get(target)));
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer sp)) {
            return;
        }
        ServerLevel level = sp.serverLevel();
        long t = level.getGameTime();
        if (t % 10L != 0L) {
            return;
        }
        int form = FormManager.get(sp);
        if (form == FormManager.NONE) {
            return;
        }
        if (form == FormManager.SUPREME && t > Keys.data(sp).getLong(Keys.SUPREME)) {
            FormManager.set(sp, FormManager.BILL);
            sp.displayClientMessage(Component.translatable("msg.billcipher.supreme_end")
                    .withStyle(ChatFormatting.GRAY), true);
            form = FormManager.BILL;
        }
        FormManager.applyFlight(sp, form);
        if (form == FormManager.SUPREME) {
            Fx.dust(level, Fx.RED, 1.4F, sp.getX(), sp.getY() + 1.0D, sp.getZ(), 6, 0.5D, 0.9D, 0.5D);
            Fx.particles(level, ParticleTypes.FLAME, sp.getX(), sp.getY() + 0.2D, sp.getZ(), 4, 0.4D, 0.1D, 0.4D, 0.02D);
        } else {
            Fx.dust(level, Fx.YELLOW, 1.0F, sp.getX(), sp.getY() + 1.0D, sp.getZ(), 3, 0.4D, 0.8D, 0.4D);
        }
    }

    /** Invulnerabilidade, e imunidades da forma Bill (queda, explosao propria). */
    @SubscribeEvent
    public static void onAttacked(LivingAttackEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) {
            return;
        }
        DamageSource src = e.getSource();
        if (src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return;
        }
        long until = Keys.data(p).getLong(Keys.INVULN);
        if (until > p.serverLevel().getGameTime()) {
            e.setCanceled(true);
            return;
        }
        int form = FormManager.get(p);
        if (form == FormManager.NONE) {
            return;
        }
        if (src.is(DamageTypeTags.IS_FALL)) {
            e.setCanceled(true);
        } else if (src.is(DamageTypeTags.IS_EXPLOSION) && src.getEntity() == p) {
            e.setCanceled(true);
        } else if (form == FormManager.SUPREME && (src.is(DamageTypeTags.IS_FIRE) || src.is(DamageTypeTags.IS_EXPLOSION))) {
            e.setCanceled(true);
        }
    }
}
