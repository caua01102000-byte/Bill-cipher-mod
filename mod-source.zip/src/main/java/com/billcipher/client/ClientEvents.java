package com.billcipher.client;

import com.billcipher.BillCipherMod;
import com.billcipher.ModItems;
import com.billcipher.net.CastPowerPacket;
import com.billcipher.net.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = BillCipherMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ClientEvents {
    private static BillModel model;

    private ClientEvents() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (ClientState.chaosLeft > 0) {
            ClientState.chaosLeft--;
        }
        if (mc.player == null || mc.level == null) {
            return;
        }
        while (ModKeys.MENU.consumeClick()) {
            if (mc.screen == null) {
                ClientState.openMenu();
            }
        }
        while (ModKeys.QUICK.consumeClick()) {
            if (mc.screen == null) {
                ModNetwork.CHANNEL.sendToServer(new CastPowerPacket(ClientState.selected));
            }
        }
    }

    /** Toque/clique esquerdo com a Roda na mao abre o menu. */
    @SubscribeEvent
    public static void onLeftClickEmpty(PlayerInteractEvent.LeftClickEmpty e) {
        if (e.getItemStack().is(ModItems.CIPHER_WHEEL.get())) {
            ClientState.openMenu();
        }
    }

    @SubscribeEvent
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock e) {
        if (e.getItemStack().is(ModItems.CIPHER_WHEEL.get())) {
            e.setCanceled(true);
            if (e.getLevel().isClientSide()
                    && e.getAction() == PlayerInteractEvent.LeftClickBlock.Action.START) {
                ClientState.openMenu();
            }
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        ClientState.clearAll();
    }

    /** Renderiza o Bill no lugar do jogador transformado. */
    @SubscribeEvent
    public static void onRenderPlayer(RenderPlayerEvent.Pre e) {
        Player p = e.getEntity();
        int form = ClientState.getForm(p.getUUID());
        if (form <= 0 || p.isInvisible() || p.isSpectator()) {
            return;
        }
        if (model == null) {
            model = new BillModel();
        }
        e.setCanceled(true);
        float pt = e.getPartialTick();
        float yaw = Mth.rotLerp(pt, p.yRotO, p.getYRot());
        float age = p.tickCount + pt;
        model.render(e.getPoseStack(), e.getMultiBufferSource(), e.getPackedLight(), age, yaw, form >= 2);
    }

    // ------------------------------------------------------------ Efeitos do Caos Dimensional
    private static int hue(float time) {
        return Mth.hsvToRgb((time * 0.01F) % 1.0F, 0.85F, 1.0F);
    }

    @SubscribeEvent
    public static void onFogColor(ViewportEvent.ComputeFogColor e) {
        float k = ClientState.chaosIntensity();
        if (k <= 0.0F || Minecraft.getInstance().level == null) {
            return;
        }
        float time = (float) e.getPartialTick() + Minecraft.getInstance().level.getGameTime();
        int rgb = hue(time * 3.0F);
        float r = ((rgb >> 16) & 255) / 255.0F;
        float g = ((rgb >> 8) & 255) / 255.0F;
        float b = (rgb & 255) / 255.0F;
        e.setRed(Mth.lerp(k, e.getRed(), r * 0.8F));
        e.setGreen(Mth.lerp(k, e.getGreen(), g * 0.3F));
        e.setBlue(Mth.lerp(k, e.getBlue(), b * 0.9F));
    }

    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles e) {
        float k = ClientState.chaosIntensity();
        if (k <= 0.0F || Minecraft.getInstance().level == null) {
            return;
        }
        float time = (float) e.getPartialTick() + Minecraft.getInstance().level.getGameTime();
        e.setRoll(e.getRoll() + Mth.sin(time * 0.09F) * 3.5F * k);
    }

    @SubscribeEvent
    public static void onFov(ViewportEvent.ComputeFov e) {
        float k = ClientState.chaosIntensity();
        if (k <= 0.0F || Minecraft.getInstance().level == null) {
            return;
        }
        float time = (float) e.getPartialTick() + Minecraft.getInstance().level.getGameTime();
        e.setFOV(e.getFOV() + Mth.sin(time * 0.13F) * 7.0D * k);
    }

    /** Pelicula colorida pulsante sobre a tela durante o caos (simula o ceu mudando de cor). */
    @SubscribeEvent
    public static void onOverlay(RenderGuiOverlayEvent.Pre e) {
        if (e.getOverlay() != VanillaGuiOverlay.VIGNETTE.type()) {
            return;
        }
        float k = ClientState.chaosIntensity();
        if (k <= 0.0F || Minecraft.getInstance().level == null) {
            return;
        }
        float time = (float) e.getPartialTick() + Minecraft.getInstance().level.getGameTime();
        int rgb = hue(time * 4.0F) & 0xFFFFFF;
        int alpha = (int) (70.0F * k * (0.7F + 0.3F * Mth.sin(time * 0.2F)));
        e.getGuiGraphics().fill(0, 0, e.getWindow().getGuiScaledWidth(), e.getWindow().getGuiScaledHeight(),
                (alpha << 24) | rgb);
    }
}
