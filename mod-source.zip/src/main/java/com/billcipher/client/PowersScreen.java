package com.billcipher.client;

import com.billcipher.net.CastPowerPacket;
import com.billcipher.net.ModNetwork;
import com.billcipher.power.Power;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.util.ArrayList;
import java.util.List;

/** Menu de poderes com botoes grandes, feito para toque (Android). */
public class PowersScreen extends Screen {
    private static boolean keepOpen = false;

    private final List<Button> powerButtons = new ArrayList<>();

    public PowersScreen() {
        super(Component.translatable("screen.billcipher.title"));
    }

    private static Component label(Power p) {
        int secs = ClientState.cooldownSeconds(p);
        MutableComponent name = p.displayName().copy();
        if (p.ordinal() == ClientState.selected) {
            name = Component.literal("> ").append(name);
        }
        if (secs > 0) {
            name.append(Component.literal(" (" + secs + "s)").withStyle(ChatFormatting.RED));
        }
        return name;
    }

    private Component keepLabel() {
        return Component.translatable(keepOpen ? "screen.billcipher.keep_on" : "screen.billcipher.keep_off");
    }

    @Override
    protected void init() {
        powerButtons.clear();
        Power[] powers = Power.values();
        int n = powers.length;
        int gap = 4;
        int availH = this.height - 24 - 34;
        int cols = 2;
        while (cols < 4
                && (int) Math.ceil(n / (double) cols) * (20 + gap) > availH
                && (this.width - 16 - gap * cols) / (cols + 1) >= 72) {
            cols++;
        }
        int rows = (int) Math.ceil(n / (double) cols);
        int bw = Math.min(160, (this.width - 16 - gap * (cols - 1)) / cols);
        int bh = Math.max(18, Math.min(32, (availH - gap * (rows - 1)) / rows));
        int totalW = cols * bw + (cols - 1) * gap;
        int x0 = (this.width - totalW) / 2;
        int y0 = 24;

        for (int i = 0; i < n; i++) {
            final Power power = powers[i];
            int cx = i % cols;
            int cy = i / cols;
            Button b = Button.builder(label(power), btn -> cast(power))
                    .bounds(x0 + cx * (bw + gap), y0 + cy * (bh + gap), bw, bh)
                    .build();
            addRenderableWidget(b);
            powerButtons.add(b);
        }

        int by = this.height - 26;
        int half = Math.max(80, Math.min(150, (this.width - 16 - gap) / 2));
        int bx = (this.width - (2 * half + gap)) / 2;
        addRenderableWidget(Button.builder(keepLabel(), btn -> {
            keepOpen = !keepOpen;
            btn.setMessage(keepLabel());
        }).bounds(bx, by, half, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.billcipher.close"), btn -> onClose())
                .bounds(bx + half + gap, by, half, 20).build());
    }

    private void cast(Power power) {
        ClientState.selected = power.ordinal();
        ModNetwork.CHANNEL.sendToServer(new CastPowerPacket(power.ordinal()));
        if (!keepOpen) {
            onClose();
        }
    }

    @Override
    public void tick() {
        super.tick();
        Power[] powers = Power.values();
        for (int i = 0; i < powerButtons.size() && i < powers.length; i++) {
            powerButtons.get(i).setMessage(label(powers[i]));
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        super.render(g, mouseX, mouseY, partialTick);
        g.drawCenteredString(this.font, this.title, this.width / 2, 8, 0xFFD83A);
    }
}
