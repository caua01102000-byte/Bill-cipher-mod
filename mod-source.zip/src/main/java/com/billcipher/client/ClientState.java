package com.billcipher.client;

import com.billcipher.power.Power;
import net.minecraft.client.Minecraft;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Estado apenas do cliente (formas dos jogadores, recargas para o menu, efeito de caos). */
public final class ClientState {
    private static final Map<UUID, Integer> FORMS = new HashMap<>();
    private static final long[] COOLDOWN_END_MS = new long[Power.values().length];

    public static int selected = Power.TRANSFORM.ordinal();
    public static int chaosTotal = 0;
    public static int chaosLeft = 0;

    private ClientState() {}

    public static int getForm(UUID id) {
        return FORMS.getOrDefault(id, 0);
    }

    public static void setForm(UUID id, int form) {
        if (form <= 0) {
            FORMS.remove(id);
        } else {
            FORMS.put(id, form);
        }
    }

    public static void clearAll() {
        FORMS.clear();
        chaosTotal = 0;
        chaosLeft = 0;
        java.util.Arrays.fill(COOLDOWN_END_MS, 0L);
    }

    public static void setCooldown(int power, int ticks) {
        if (power >= 0 && power < COOLDOWN_END_MS.length) {
            COOLDOWN_END_MS[power] = System.currentTimeMillis() + ticks * 50L;
        }
    }

    public static int cooldownSeconds(Power p) {
        long left = COOLDOWN_END_MS[p.ordinal()] - System.currentTimeMillis();
        return left <= 0L ? 0 : (int) ((left + 999L) / 1000L);
    }

    public static void startChaos(int ticks) {
        chaosTotal = ticks;
        chaosLeft = ticks;
    }

    /** 0..1 com entrada/saida suaves. */
    public static float chaosIntensity() {
        if (chaosLeft <= 0 || chaosTotal <= 0) {
            return 0.0F;
        }
        float in = Math.min(1.0F, (chaosTotal - chaosLeft) / 20.0F);
        float out = Math.min(1.0F, chaosLeft / 30.0F);
        return Math.min(in, out);
    }

    public static void openMenu() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            mc.setScreen(new PowersScreen());
        }
    }
}
