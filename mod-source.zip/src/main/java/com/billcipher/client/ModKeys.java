package com.billcipher.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

/** Teclas opcionais (o mod funciona so com toque; no MojoLauncher voce pode mapear botoes na tela para elas). */
public final class ModKeys {
    public static final String CATEGORY = "key.categories.billcipher";

    public static final KeyMapping MENU = new KeyMapping("key.billcipher.menu",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, CATEGORY);
    public static final KeyMapping QUICK = new KeyMapping("key.billcipher.quick",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, CATEGORY);

    private ModKeys() {}
}
