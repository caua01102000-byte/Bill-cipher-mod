package com.billcipher.client;

import com.billcipher.BillCipherMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Modelo 3D do Bill Cipher: triangulo em degraus, olho unico, cartola, gravata-borboleta,
 * bracos e pernas finos. Construido no codigo (sem arquivo de modelo) e flutuando com animacao.
 */
public class BillModel extends Model {
    public static final ResourceLocation TEXTURE =
            new ResourceLocation(BillCipherMod.MODID, "textures/entity/bill.png");
    public static final ResourceLocation TEXTURE_SUPREME =
            new ResourceLocation(BillCipherMod.MODID, "textures/entity/bill_supreme.png");

    private final ModelPart root;
    private final ModelPart leftArm;
    private final ModelPart rightArm;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;
    private final ModelPart pupil;

    public BillModel() {
        super(RenderType::entityCutoutNoCull);
        this.root = createLayer().bakeRoot();
        this.leftArm = root.getChild("left_arm");
        this.rightArm = root.getChild("right_arm");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
        this.pupil = root.getChild("eye_pupil");
    }

    // Faixas da textura (64x64): y 0-15 corpo, 16-31 branco, 32-47 preto, 48-63 azul
    private static final int BODY = 0;
    private static final int WHITE = 16;
    private static final int BLACK = 32;
    private static final int BLUE = 48;

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();

        int[] widths = {2, 4, 6, 8, 10, 12};
        for (int i = 0; i < widths.length; i++) {
            float w = widths[i];
            r.addOrReplaceChild("layer" + i,
                    CubeListBuilder.create().texOffs(0, BODY).addBox(-w / 2.0F, i * 3.0F, -1.0F, w, 3.0F, 2.0F),
                    PartPose.ZERO);
        }
        r.addOrReplaceChild("eye_white",
                CubeListBuilder.create().texOffs(0, WHITE).addBox(-2.0F, 7.0F, -2.0F, 4.0F, 3.0F, 1.0F), PartPose.ZERO);
        r.addOrReplaceChild("eye_pupil",
                CubeListBuilder.create().texOffs(0, BLACK).addBox(-1.0F, 8.0F, -3.0F, 2.0F, 2.0F, 1.0F), PartPose.ZERO);
        r.addOrReplaceChild("hat_brim",
                CubeListBuilder.create().texOffs(0, BLACK).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.ZERO);
        r.addOrReplaceChild("hat_top",
                CubeListBuilder.create().texOffs(0, BLACK).addBox(-2.0F, -6.0F, -1.5F, 4.0F, 5.0F, 3.0F), PartPose.ZERO);
        r.addOrReplaceChild("hat_band",
                CubeListBuilder.create().texOffs(0, BLUE).addBox(-2.1F, -2.5F, -1.6F, 4.2F, 1.0F, 3.2F), PartPose.ZERO);
        r.addOrReplaceChild("bow_l",
                CubeListBuilder.create().texOffs(0, BLUE).addBox(-4.0F, 13.5F, -2.0F, 3.0F, 2.0F, 1.0F), PartPose.ZERO);
        r.addOrReplaceChild("bow_r",
                CubeListBuilder.create().texOffs(0, BLUE).addBox(1.0F, 13.5F, -2.0F, 3.0F, 2.0F, 1.0F), PartPose.ZERO);
        r.addOrReplaceChild("bow_knot",
                CubeListBuilder.create().texOffs(0, BLUE).addBox(-1.0F, 13.5F, -2.2F, 2.0F, 2.0F, 1.2F), PartPose.ZERO);
        r.addOrReplaceChild("left_arm",
                CubeListBuilder.create().texOffs(0, BLACK).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 9.0F, 1.0F),
                PartPose.offset(7.5F, 10.0F, 0.0F));
        r.addOrReplaceChild("right_arm",
                CubeListBuilder.create().texOffs(0, BLACK).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 9.0F, 1.0F),
                PartPose.offset(-7.5F, 10.0F, 0.0F));
        r.addOrReplaceChild("left_leg",
                CubeListBuilder.create().texOffs(0, BLACK).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 6.0F, 1.0F),
                PartPose.offset(2.0F, 18.0F, 0.0F));
        r.addOrReplaceChild("right_leg",
                CubeListBuilder.create().texOffs(0, BLACK).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 6.0F, 1.0F),
                PartPose.offset(-2.0F, 18.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    public void render(PoseStack ps, MultiBufferSource buffers, int light, float ageTicks, float yawDeg, boolean supreme) {
        float swing = Mth.sin(ageTicks * 0.12F);
        leftArm.zRot = -0.15F - swing * 0.12F;
        rightArm.zRot = 0.15F + swing * 0.12F;
        leftLeg.xRot = Mth.sin(ageTicks * 0.1F) * 0.25F;
        rightLeg.xRot = -Mth.sin(ageTicks * 0.1F) * 0.25F;
        pupil.x = Mth.sin(ageTicks * 0.05F) * 0.6F;

        ps.pushPose();
        float scale = supreme ? 1.4F : 1.0F;
        ps.mulPose(Axis.YP.rotationDegrees(180.0F - yawDeg));
        ps.scale(-scale, -scale, scale);
        float bob = Mth.sin(ageTicks * 0.08F) * 0.06F;
        ps.translate(0.0F, -1.501F - 0.15F - bob, 0.0F);

        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(supreme ? TEXTURE_SUPREME : TEXTURE));
        this.renderToBuffer(ps, vc, supreme ? LightTexture.FULL_BRIGHT : light, OverlayTexture.NO_OVERLAY,
                1.0F, 1.0F, 1.0F, 1.0F);
        ps.popPose();
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay,
                               float r, float g, float b, float a) {
        root.render(ps, vc, light, overlay, r, g, b, a);
    }
}
