package com.billcipher.net;

import com.billcipher.BillCipherMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(BillCipherMod.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private static int nextId = 0;

    private ModNetwork() {}

    public static void register() {
        CHANNEL.registerMessage(nextId++, CastPowerPacket.class,
                CastPowerPacket::encode, CastPowerPacket::decode, CastPowerPacket::handle);
        CHANNEL.registerMessage(nextId++, FormSyncPacket.class,
                FormSyncPacket::encode, FormSyncPacket::decode, FormSyncPacket::handle);
        CHANNEL.registerMessage(nextId++, ChaosPacket.class,
                ChaosPacket::encode, ChaosPacket::decode, ChaosPacket::handle);
        CHANNEL.registerMessage(nextId++, CooldownPacket.class,
                CooldownPacket::encode, CooldownPacket::decode, CooldownPacket::handle);
        CHANNEL.registerMessage(nextId++, OpenMenuPacket.class,
                OpenMenuPacket::encode, OpenMenuPacket::decode, OpenMenuPacket::handle);
    }
}
