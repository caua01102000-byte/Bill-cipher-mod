package com.billcipher.net;

import com.billcipher.client.ClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Servidor -> Cliente: inicia o efeito visual de Caos Dimensional (cor do ceu/nevoa, camera). */
public class ChaosPacket {
    private final int ticks;

    public ChaosPacket(int ticks) {
        this.ticks = ticks;
    }

    public static void encode(ChaosPacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.ticks);
    }

    public static ChaosPacket decode(FriendlyByteBuf buf) {
        return new ChaosPacket(buf.readVarInt());
    }

    public static void handle(ChaosPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientState.startChaos(m.ticks)));
        c.setPacketHandled(true);
    }
}
