package com.billcipher.net;

import com.billcipher.power.Keys;
import com.billcipher.power.Power;
import com.billcipher.power.PowerManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Cliente -> Servidor: pede para lancar um poder (e o seleciona para o uso rapido da Roda). */
public class CastPowerPacket {
    private final int power;

    public CastPowerPacket(int power) {
        this.power = power;
    }

    public static void encode(CastPowerPacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.power);
    }

    public static CastPowerPacket decode(FriendlyByteBuf buf) {
        return new CastPowerPacket(buf.readVarInt());
    }

    public static void handle(CastPowerPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer p = c.getSender();
            Power power = Power.byIndex(m.power);
            if (p != null && power != null) {
                Keys.data(p).putInt(Keys.SEL, power.ordinal());
                PowerManager.cast(p, power);
            }
        });
        c.setPacketHandled(true);
    }
}
