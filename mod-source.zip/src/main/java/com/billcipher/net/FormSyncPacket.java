package com.billcipher.net;

import com.billcipher.client.ClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.UUID;
import java.util.function.Supplier;

/** Servidor -> Cliente: forma (0/1/2) de um jogador, usada para renderizar o Bill. */
public class FormSyncPacket {
    private final UUID id;
    private final int form;

    public FormSyncPacket(UUID id, int form) {
        this.id = id;
        this.form = form;
    }

    public static void encode(FormSyncPacket m, FriendlyByteBuf buf) {
        buf.writeUUID(m.id);
        buf.writeVarInt(m.form);
    }

    public static FormSyncPacket decode(FriendlyByteBuf buf) {
        return new FormSyncPacket(buf.readUUID(), buf.readVarInt());
    }

    public static void handle(FormSyncPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientState.setForm(m.id, m.form)));
        c.setPacketHandled(true);
    }
}
