package com.billcipher.net;

import com.billcipher.client.ClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Servidor -> Cliente: recarga de um poder (para mostrar o tempo restante no menu). */
public class CooldownPacket {
    private final int power;
    private final int ticks;

    public CooldownPacket(int power, int ticks) {
        this.power = power;
        this.ticks = ticks;
    }

    public static void encode(CooldownPacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.power);
        buf.writeVarInt(m.ticks);
    }

    public static CooldownPacket decode(FriendlyByteBuf buf) {
        return new CooldownPacket(buf.readVarInt(), buf.readVarInt());
    }

    public static void handle(CooldownPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientState.setCooldown(m.power, m.ticks)));
        c.setPacketHandled(true);
    }
}
