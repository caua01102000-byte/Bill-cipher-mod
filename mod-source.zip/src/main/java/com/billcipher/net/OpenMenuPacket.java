package com.billcipher.net;

import com.billcipher.client.ClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Servidor -> Cliente: abre o menu de poderes (usado pelo comando /billcipher menu). */
public class OpenMenuPacket {
    public OpenMenuPacket() {}

    public static void encode(OpenMenuPacket m, FriendlyByteBuf buf) {}

    public static OpenMenuPacket decode(FriendlyByteBuf buf) {
        return new OpenMenuPacket();
    }

    public static void handle(OpenMenuPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientState.openMenu()));
        c.setPacketHandled(true);
    }
}
