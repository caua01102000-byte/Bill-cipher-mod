package com.billcipher;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, BillCipherMod.MODID);

    public static final RegistryObject<SoundEvent> CAST = reg("cast");
    public static final RegistryObject<SoundEvent> TRANSFORM = reg("transform");
    public static final RegistryObject<SoundEvent> LAUGH = reg("laugh");
    public static final RegistryObject<SoundEvent> BLAST = reg("blast");
    public static final RegistryObject<SoundEvent> TELEPORT = reg("teleport");
    public static final RegistryObject<SoundEvent> EYE = reg("eye");
    public static final RegistryObject<SoundEvent> TELEKINESIS = reg("telekinesis");
    public static final RegistryObject<SoundEvent> EXPLOSION = reg("explosion");
    public static final RegistryObject<SoundEvent> MIND = reg("mind");
    public static final RegistryObject<SoundEvent> PORTAL = reg("portal");
    public static final RegistryObject<SoundEvent> CHAOS = reg("chaos");
    public static final RegistryObject<SoundEvent> SHIELD = reg("shield");
    public static final RegistryObject<SoundEvent> SUPREME = reg("supreme");

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name,
                () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(BillCipherMod.MODID, name)));
    }

    private ModSounds() {}
}
