package com.billcipher;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, BillCipherMod.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, BillCipherMod.MODID);

    public static final RegistryObject<Item> CIPHER_WHEEL = ITEMS.register("cipher_wheel",
            () -> new CipherWheelItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("billcipher",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.billcipher"))
                    .icon(() -> new ItemStack(CIPHER_WHEEL.get()))
                    .displayItems((params, output) -> output.accept(CIPHER_WHEEL.get()))
                    .build());

    private ModItems() {}
}
