package com.billcipher;

import net.minecraftforge.common.ForgeConfigSpec;

/** Configuracao (arquivo config/billcipher-common.toml). */
public final class BillConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue EXPLOSION_BREAKS_BLOCKS;
    public static final ForgeConfigSpec.BooleanValue FLIGHT_IN_BILL_FORM;
    public static final ForgeConfigSpec.BooleanValue GIVE_WHEEL_ON_JOIN;
    public static final ForgeConfigSpec.DoubleValue COOLDOWN_MULTIPLIER;
    public static final ForgeConfigSpec.IntValue REALITY_RADIUS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("billcipher");
        EXPLOSION_BREAKS_BLOCKS = b
                .comment("Se verdadeiro, a Explosao Caotica destroi blocos. Padrao: false (so causa dano).")
                .define("explosionBreaksBlocks", false);
        FLIGHT_IN_BILL_FORM = b
                .comment("Se verdadeiro, a forma Bill permite voar (Bill flutua).")
                .define("flightInBillForm", true);
        GIVE_WHEEL_ON_JOIN = b
                .comment("Entrega uma Roda de Cifras na primeira vez que o jogador entra no mundo.")
                .define("giveWheelOnFirstJoin", true);
        COOLDOWN_MULTIPLIER = b
                .comment("Multiplicador dos tempos de recarga (0 = sem recarga, 2 = o dobro).")
                .defineInRange("cooldownMultiplier", 1.0D, 0.0D, 10.0D);
        REALITY_RADIUS = b
                .comment("Raio (em blocos) da Manipulacao da Realidade. Menor = mais leve no celular.")
                .defineInRange("realityRadius", 5, 1, 12);
        b.pop();
        SPEC = b.build();
    }

    private BillConfig() {}
}
