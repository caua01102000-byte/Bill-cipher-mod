package com.billcipher;

import com.billcipher.power.Keys;
import com.billcipher.power.Power;
import com.billcipher.power.PowerManager;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Roda de Cifras.
 * - Usar o item (botao "usar" do celular / clique direito): lanca o poder selecionado.
 * - Tocar/clicar com o botao esquerdo: abre o menu de poderes (tratado no cliente).
 */
public class CipherWheelItem extends Item {
    public CipherWheelItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            CompoundTag data = Keys.data(sp);
            int sel = data.contains(Keys.SEL) ? data.getInt(Keys.SEL) : Power.TRANSFORM.ordinal();
            Power power = Power.byIndex(sel);
            if (power != null) {
                PowerManager.cast(sp, power);
            }
        }
        player.getCooldowns().addCooldown(this, 5);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.billcipher.cipher_wheel.tip1").withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.translatable("item.billcipher.cipher_wheel.tip2").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("item.billcipher.cipher_wheel.tip3").withStyle(ChatFormatting.GRAY));
    }
}
